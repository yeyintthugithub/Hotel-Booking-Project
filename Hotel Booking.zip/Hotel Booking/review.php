<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Hotel Booking</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
    
    <style>
        .well
        {
            background: rgba(0,0,0,0.5);
            border: none;
        }

    
        
        .wellfix
        {
            background: rgba(0,0,0,0.7);
            border: none;
            height: 150px;
        }
		body
		{
			background-image: url('images/home_bg.jpg');
			background-repeat: no-repeat;
			background-attachment: fixed;
		}
       
        p
        {
            font-size: 15px;
        }
        .jumbotrons
        {
            background: rgba(0,0,0,0.5);
            border: none;   
        }

    </style>
    
    
</head>

<body>
    <div class="container">
      
      
       <img class="img-responsive" src="images/home_banner.jpg" style="width:100%; height:180px;">      
        <nav class="navbar navbar-inverse">
            <div class="container-fluid">
                <ul class="nav navbar-nav">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="room.php">Room &amp; Facilities</a></li>
                    <li><a href="reservation.php">Online Reservation</a></li>
                    <li class="active"><a href="review.php">Review & Facilities</a></li>
                    <li><a href="admin.php">Admin</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="http://www.facebook.com"><img src="images/facebook.png"></a></li>
                    <li><a href="http://www.twitter.com"><img src="images/twitter.png"></a></li>                    
                </ul>
            </div>
        </nav>

     
<div class="jumbotrons">
    <div class="#">
        <div class="container">
            <div class="row">
                <div class="col-sm-4">   
                    <img  src="images/home_gallary/1.jpg" style="width:350px; height:350px;">
                </div>
                <div class="col-sm-4">
                    <img  src="images/home_gallary/2.jpg" style="width:350px; height:350px;">
                </div>
                <div class="col-sm-4">
                    <img  src="images/home_gallary/3.jpg" style="width:350px; height:350px;">
                </div>
            </div>
        </div><br><br>
        <div class="container">
            <div class="row">
                <div class="col-sm-4"> 
                    <img  src="images/home_gallary/4.jpg" style="width:350px; height:350px;">
                </div>
                <div class="col-sm-4">
                    <img  src="images/home_gallary/5.jpg" style="width:350px; height:350px;">
                </div>
                <div class="col-sm-4">
                    <img  src="images/home_gallary/6.jpg" style="width:350px; height:350px;">
                </div>
            </div>
        </div><br><br>
        <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <img  src="images/home_gallary/18.jpg" style="width:350px; height:350px;">
                </div>
                <div class="col-sm-4">
                    <img  src="images/home_gallary/19.jpg" style="width:350px; height:350px;">
                </div>
                <div class="col-sm-4">
                    <img  src="images/home_gallary/20.jpg" style="width:350px; height:350px;">
                </div>
            </div>    
        </div><br><br>
    </div>
</div>

<hr>
    
   <div class="row" style="color: #ed9e21">
            <div class="col-md-12 well" ><br><br><br>
              <h5><strong style="color: #ffbb2b">Cutsomer Reviews</strong></h5><br>

              <p>Breakfast I feel some dishes are not freshly made, like breads and waffle , some hard and fruits also spoil and still keep at the menu,, maybe they repeating the leftover.Excellent hotel to stay and is worth for value in city. Breakfast is superb. Staffs are friendly and always give me happy morning face and also willing to help.
              Nice room with reasonable price - nice view from my room</p>
             
              
            </div>  
        </div> 
       
       <div class="row" style="color: #ffbb2b">
            <div class="col-md-4 wellfix">
              <h4><strong>Contact Us</strong></h4><hr>
              Address : Yangon<br>
              EMail    : echo@gmail.com <br>
              Phone   : 09785494946 <br>
            </div>
            <div class="col-md-4"></div>
            <div class="col-md-4 wellfix">
                <h4><strong>Developed By</strong></h4><hr>
                <a href="">Echo </a><br><br>
                <p class="fl_left">Copyright &copy; 2023 - All Rights Reserved - <a href="#">Mr. Echo</a></p>

            </div>
        </div> 



    </div>
<
    
    
    





    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
</body>

</html>